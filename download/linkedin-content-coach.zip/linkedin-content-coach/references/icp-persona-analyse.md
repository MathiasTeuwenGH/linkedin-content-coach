# Ideale klant en persona-analyse

Noem dit tegen de gebruiker altijd "de ideale klant en persona-analyse" (geen afkortingen zoals ICP). Ze bevat ook de inzichten voor de communicatie.

Gebruik dit zodra de contentgids er is (ook als ze maar deels ingevuld is), als onderdeel van de kennismaking. Of later, wanneer de gebruiker vraagt om zijn ideale klant, persona of communicatiestrategie scherp te zetten.

De analyse vat alle context samen in een overzicht dat de gebruiker kan bewaren en dat jij gebruikt bij elke post: wie de ideale klant is, hoe die denkt en beslist, en wat dat betekent voor de communicatie.

## Bronnen verzamelen

Hoe meer echte bronnen, hoe beter de analyse. Gebruik:
1. **De contentgids**: de belangrijkste bron, en de enige bron van waarheid als bronnen elkaar tegenspreken.
2. **De website** van de gebruiker. Kan je in dit gesprek websites bezoeken, lees dan de homepagina, de pagina over het aanbod en de over-ons-pagina. Kan dat niet, vraag dan om de belangrijkste teksten te plakken.
3. **Gekoppelde tools**: gespreksopnames (bv. Fathom), ingesproken notities (bv. Wispr Flow), Notion, Google Drive. Zoek naar gesprekken met klanten en prospects, klantdossiers en notities.
4. **Bedrijfsdocumenten** die de gebruiker uploadt: een salesdeck, een offerte, klantcases, getuigenissen, een eerder marketingplan.

Vraag in de kennismaking één keer kort naar wat er nog is, en werk dan met wat er is. Ontbreekt er een bron, ga dan toch verder en zeg welke bron de analyse sterker zou maken.

## Hoe je de analyse maakt

Neem de rol van een ervaren groeistrateeg: praktisch, beknopt, toegankelijk en verhalend. Liever concrete, ongewone aanpakken dan theorie.

Regels:
- Alles komt uit de bronnen. Zeg bij belangrijke punten waar het vandaan komt (contentgids, website, welk gesprek, welk document).
- Interpretaties en aannames zet je tussen [haakjes]. Verzin geen klanten, cijfers of citaten.
- Gebruik de letterlijke woorden van klanten waar het kan.
- De gebruiker kent zijn klant het best. De analyse is een vertrekpunt dat hij bijstuurt, geen eindoordeel.

### Deel 1: het bedrijf

- **Wat het bedrijf doet:** een overzicht van wat het doet, de eigen aanpak en de plaats in de markt.
- **Waardepropositie:** de belangrijkste voordelen en de waarde die het levert.
- **Marktbehoefte:** welk gat of welke nood in de markt het invult.

### Deel 2: het ideale klantprofiel (ICP), als tabel

Vul per criterium in wat bij dit bedrijf past, met een korte uitleg waarom:

| Criterium | Wat je invult |
|---|---|
| Bedrijfsgrootte | Het aantal medewerkers waarbinnen het aanbod goed werkt (minimum en maximum) |
| Sector | De sectoren die er het meest aan hebben en er het meest voor openstaan |
| Financiële stabiliteit | Bedrijven met stabiele of groeiende inkomsten, die bij een dip niet als eerste op dit soort uitgaven besparen |
| Bedrijfscultuur | De waarden en gewoontes die passen bij de aanpak van de gebruiker |
| Regio | Waar het aanbod geleverd kan worden en waar veel bedrijven zitten die aan de andere criteria voldoen |
| Beslisser | De rollen of functies die beslissen en het budget beheren |
| Budget | Het gebruikelijke budget voor dit aanbod, en of de doelgroep dat kan en wil uitgeven |
| Eerdere ervaring | Of ze al eerder in gelijkaardige diensten of oplossingen investeerden, en wat dat zegt over hun bereidheid |
| Waardenmatch | Hoe goed de waarden van de klant aansluiten bij wat het aanbod oplevert |
| Groeifase | Of ze groeien of willen groeien, en hoe het aanbod daarbij helpt |

Voor een zelfstandige of een klein bedrijf als klant vertaal je de criteria naar die situatie (bv. "bedrijfsgrootte" wordt "eenmanszaak of klein team").

### Deel 3: de buyer persona, als tabel

Eén persona, gebaseerd op de ideale klant uit de contentgids en de rest van de bronnen:

| Onderdeel | Wat je invult |
|---|---|
| Naam | Een herkenbare voornaam (geen echte klantnaam) |
| Functie | Functie of rollen |
| Professionele achtergrond | Ervaring en expertise |
| Doelen | Wat de persona professioneel wil bereiken |
| Aankoopproces | De stappen die de persona zet bij het overwegen en kopen van zo'n aanbod |
| Mogelijke drempels | Wat de persona kan tegenhouden om te kopen |
| Taken en activiteiten | Wat de persona dagelijks doet dat te maken heeft met het aanbod |
| Functionele pijn | Wat praktisch misloopt als de doelen niet gehaald worden |
| Emotionele pijn | Hoe dat voelt |
| Functionele winst | Wat praktisch beter wordt als de pijn opgelost is |
| Emotionele winst | Hoe dat voelt |

### Deel 4: communicatiestrategie

De 5 belangrijkste inzichten uit dit onderzoek voor de communicatie. Per inzicht:
- waarom het belangrijk is om de doelgroep te bereiken
- wat het betekent voor de boodschap en de aanpak
- concrete aanbevelingen, met voorbeelden waar het kan

Vertaal de inzichten ook naar LinkedIn: welke onderwerpen, posttypes (zie `posttypes.md`) en woorden van klanten het best werken.

## Hoe je het oplevert

- Maak er één document van met duidelijke tussentitels, de twee tabellen, en weinig of geen emoji. Het moet zo in Notion, Google Docs of Word te plakken zijn. Kan je in dit gesprek een bestand of document maken, doe dat dan. Anders lever je het als één blok tekst.
- Zet in het gesprek zelf alleen een korte samenvatting, in chatvorm: drie zinnen met wat je het meest opviel.
- Bewaar de analyse in het brein (`analyse.md`) met status "voorstel" en de datum. Na de bevestiging van de gebruiker wordt dat "bevestigd", met datum.

## Feedback van de gebruiker

De gebruiker kent zijn klant het best. Geef hem echt de kans om bij te sturen, kort en in chatvorm:

1. **Eerst de 3 belangrijkste aannames:** wat je zelf afleidde en niet letterlijk in de bronnen vond (alles wat tussen [haakjes] staat). Eén bericht, bv.:
   > Drie dingen leidde ik zelf af. Klopt dit?
   > 1. Je ideale klant heeft [10 à 50] medewerkers.
   > 2. De beslisser is meestal [de zaakvoerder].
   > 3. [Budget] is de grootste drempel.
2. **Dan de vier delen, één per bericht**, telkens met één gerichte vraag: het bedrijf (klopt hoe je jezelf beschrijft en de nood in de markt?), de ideale klant (klopt de tabel, mist er een criterium?), de persona (herken je deze persoon, welke pijn of drempel klopt niet?), en de 5 inzichten (welke spreekt je het meest aan?). Zegt hij "ok" of "verder", ga dan door.
3. **Verwerk elke aanpassing meteen** in de analyse en in het brein, en zeg in één zin wat je veranderde.
4. **Na de laatste vraag:** zet de status op "bevestigd", met datum.

Later bijsturen kan altijd ("pas mijn ideale klant aan"). Komt er belangrijke nieuwe informatie bij (een nieuwe versie van de contentgids, een nieuw aanbod, veel nieuwe klantgesprekken), stel dan voor om de analyse bij te werken. Nooit zonder dat de gebruiker het bevestigt.

## De analyse als toetssteen

De bevestigde analyse is de maatstaf voor elke keuze daarna:
- **Elke post:** de vaste kop vermeldt voor wie de post is en welke pijn, welk doel of welke drempel van de persona hij raakt (zie SKILL.md). De eindcontrole toetst of de post relevant is voor de ideale klant en de persona (zie `eindcontrole.md`, deel 1).
- **Postideeën, klantcases en de planning:** zet de ideeën die het best passen bij de ideale klant en de persona eerst, en zeg in een paar woorden waarom.
- **Profiel en Sales Navigator:** de ideale klant en de persona bepalen de woorden en de filters.

Is de analyse nog een voorstel (niet bevestigd), zeg dat erbij als je ze gebruikt.
- Neem de kern op in het bedrijfsprofiel (zie `kennismaking.md`): de ICP in een paar regels, de persona, de functionele en emotionele pijn en winst, en de 5 inzichten in één zin elk.

## Na de analyse: verschillen en positionering

In de kennismaking volgen na de analyse nog twee stappen: de verschillen tussen de contentgids en de andere bronnen nakijken, en de positionering scherpstellen. Hoe je dat doet: zie `kennismaking.md`, stap 5.

## Hoe je de analyse daarna gebruikt

- **Promoposts:** de functionele en emotionele pijn, de drempels en de emotionele winst van de persona.
- **Perspectiveposts:** de marktbehoefte en de inzichten uit de communicatiestrategie.
- **Proofposts:** de doelen en de functionele winst, gekoppeld aan echte klantresultaten.
- **LinkedIn-profiel en Sales Navigator:** de beslisser, de sector, de bedrijfsgrootte, de regio en de groeifase uit de ICP, en de functie en achtergrond van de persona (zie `sales-navigator.md`).
