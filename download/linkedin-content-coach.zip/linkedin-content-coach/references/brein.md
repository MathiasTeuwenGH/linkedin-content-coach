# Het brein: alle context van de gebruiker op één plek

Een goede post, carrousel of animatie is zo sterk als de feiten, de stem en de huisstijl erachter. Daarom bouw je voor elke gebruiker een **brein**: een vaste map met wat je over hem weet, met bronnen. Je bouwt het tijdens de kennismaking (zie `kennismaking.md`) en laat het groeien bij elk gebruik.

## De drie regels

1. **Eerst halen, dan vragen.** Lees eerst wat er al is: de contentgids, de website, geüploade documenten (salesdeck, offerte, klantcase, stijlgids) en gekoppelde tools (gespreksopnames, notities, Drive, Notion). Vraag daarna alleen wat ontbreekt, één vraag per bericht.
2. **Letterlijk, met bron.** Citaten woord voor woord. Elk cijfer met periode, aantal en bron. Elke regel zegt waar hij vandaan komt en wanneer.
3. **Een voorstel is geen feit.** Wat jij afleidt (kleuren van de website, een stijlregel, een samenvatting) krijgt het label "voorstel" tot de gebruiker het bevestigt. Wat niemand weet, blijft leeg. Vul nooit zelf iets in om een gat te dichten.

## De map

```
brein/
  profiel.md        wie, wat, voor wie, aanbod, positionering (korte samenvatting)
  analyse.md        ideale klant en persona-analyse, met status (voorstel of bevestigd) en datum
  kernboodschappen.md  de 6 à 8 boodschappen waar al de content naar terugkeert, met klantwoorden en bewijs
  bewijsbank.md     cijfers, resultaten en klantverhalen, met bron en of ze publiek mogen
  klantentaal.md    letterlijke woorden van klanten en prospects
  stem.md           verboden constructies, voorbeeldposts, wat hij zelf aanpast
  huisstijl.md      kleuren, lettertypes, logo, regels
  huisstijl/        het logo en de lettertypes als bestand, de stijlgids
  bronnen/          de ruwe stukken (contentgids, transcripten, documenten), nooit herschreven
  posts.md          elke gepubliceerde post, met datum en resultaten
  planning.md       de contentplanning: wat gepland is, per week
  leadmagnets.md    ideeën voor gratis waarde en lead magnets, met status en resultaten
```

## Waar het brein staat

Vraag het in stap 8 van de kennismaking. Het moet blijven bestaan tussen gesprekken.

| Waar | Hoe je het bijwerkt |
|---|---|
| Een map op de computer van de gebruiker die gekoppeld is (bv. in Cowork) | Je schrijft en werkt de bestanden zelf bij. Beste keuze. |
| Google Drive of Notion, gekoppeld | Je schrijft erin als de koppeling dat toelaat. Anders zoals hieronder. |
| Een project in de AI-assistent (Claude, ChatGPT) | Je maakt de bestanden, de gebruiker zet ze in de projectbestanden. Na een update geef je het gewijzigde bestand en zeg je welk bestand hij vervangt. |
| Nergens | Je geeft de bestanden als download. Hij laadt ze op bij de start van een nieuw gesprek. Raad een van de andere opties aan. |

Begint een gesprek en vind je een brein? Lees eerst `profiel.md` en wat je voor de taak nodig hebt (`bewijsbank.md` bij cijfers, `huisstijl.md` bij visuals, `stem.md` en `kernboodschappen.md` bij elke post). Zeg in één zin dat je het brein gevonden hebt.

## Hoe je elk deel vult

| Deel | Eerst halen uit | Dan vragen (voorbeeld) | Groeit door |
|---|---|---|---|
| Profiel | contentgids, website | Alleen wat vaag of tegenstrijdig is | Nieuwe info over aanbod of doelgroep |
| Analyse | contentgids, website, documenten | "Klopt dit beeld van je ideale klant?" | Bijsturen na gesprekken en reacties |
| Bewijsbank | contentgids (deel 1, 3 en 5), klantcases, salesdeck, offertes, gesprekken | "Je schrijft dat klanten sneller beslissen. Hoeveel klanten, over welke periode, en waar zie je dat?" en "Mag dit publiek?" | Elk resultaat dat in een gesprek of post opduikt |
| Klantentaal | gespreksopnames, mails of reviews die hij deelt, contentgids deel 1 | "Mag ik citaten met naam gebruiken, of alleen anoniem?" | Na elk klantgesprek: de beste zinnen |
| Stem | schrijfstijlgids, eigen posts | De verboden constructies tonen en vragen wat erbij of eraf moet; "Plak 3 à 5 posts die echt als jou klinken" | Elke eindversie die hij zelf aanpast |
| Huisstijl | stijlgids of brandbook, geüploade logo- en lettertypebestanden, website | "Heb je een stijlgids? Upload hem gerust." en "Dit vond ik op je website. Klopt dat?" | Elke visual die hij goed of slecht vindt |
| Bronnen | alles wat hij uploadt of koppelt | Niets | Elk nieuw document of transcript |
| Posts | | "Hoe deed je post het na een week?" | Resultaten na elke post |

### Huisstijl zonder stijlgids

1. Heeft hij een website: lees de kleuren (kleurcodes), de lettertypes en het logo van de site. Zet ze in `huisstijl.md` als voorstel en vraag of het klopt. Vraag daarna het logo als bestand (liefst .svg, of .png met transparante achtergrond) en de lettertypebestanden.
2. Geen website of geen huisstijl: stel een eenvoudige startstijl voor (twee kleuren plus zwart en wit, één lettertype, veel witruimte) en label die als voorstel.
3. Neem nooit de huisstijl over van een voorbeeld of een andere maker.

## Het brein laten groeien

Vraag het op een natuurlijk moment, met één korte vraag, en voeg pas toe na een ja:
- **Na elke post:** zodra hij een versie kiest, vraag altijd: "Wil je de post hier plakken zoals je hem uiteindelijk post? Zo leer ik je stem beter kennen." Zet de finale post in `posts.md` en wat hij veranderde in `stem.md`. Vraag het ook als hij niets lijkt aan te passen: ook dat is een les.
- **Na een klantgesprek:** "Ik vond 3 sterke zinnen en 1 resultaat. Toevoegen aan je brein?"
- **Bij een cijfer in een post of visual:** kijk eerst in `bewijsbank.md`. Staat het er niet in, vraag het dan. Geen cijfer op een post of beeld zonder bron.
- **Resultaten:** je kunt niet uit jezelf terugkomen. Vraag bij de finale post om over een paar dagen terug te komen met de resultaten (impressies, reacties van de juiste mensen, gesprekken). Komt hij terug, zet het dan in `posts.md`.
- **Elke maand:** stel voor om deel 5 van de contentgids (wins en wat hij bouwt) aan te vullen.
- **Bij belangrijke nieuwe informatie** (een nieuwe versie van de contentgids, een nieuw aanbod, veel nieuwe klantgesprekken): stel voor om de ideale klant en persona-analyse bij te werken (zie `icp-persona-analyse.md`).

Werk het brein bij aan het eind van een taak, niet midden in een gesprek. Zeg in één zin wat er bijkwam.

## Sjablonen

### bewijsbank.md

```
# Bewijsbank
Laatst bijgewerkt: [datum]

## Mag publiek
| Wat | Waarde | Periode | Op hoeveel klanten | Bron | Bevestigd op |
|---|---|---|---|---|---|

## Nog na te kijken
| Wat | Wat ontbreekt | Bron |
|---|---|---|

## Niet publiek
| Wat | Waarom niet | Bron |
|---|---|---|
```

### klantentaal.md

```
# Klantentaal
| Citaat (letterlijk) | Wie (functie, soort bedrijf) | Bron en datum | Gaat over | Naam mag |
|---|---|---|---|---|
```

"Gaat over": pijn, bezwaar, verlangen, resultaat, vraag.

### stem.md

```
# Stem
Laatst bijgewerkt: [datum]

## Verboden constructies
(uit de schrijfstijlgids; bevestigd op [datum])
- Gedachtestreepjes (— of –)
- "Laten we eerlijk zijn" / "want eerlijk?" of iets vergelijkbaars
- "Het mooie?"
- De constructie "Niet ..., maar ..."
- "Herkenbaar?" als losse vraag
- Hashtags
- Emoji-opsommingen
- Vet, cursief of onderlijnd
- [toegevoegd door de gebruiker]

## Zo klinkt hij
(samenvatting uit de voorbeeldposts: lengte, begin, einde, ik/jij/wij, toon, woorden die terugkomen)

## Voorbeeldposts
(letterlijk, met datum)

## Wat hij zelf aanpaste
| Datum | Post | Wat hij veranderde | Les voor de volgende post |
|---|---|---|---|
```

### huisstijl.md

```
# Huisstijl
Status: [bevestigd / voorstel]   Bron: [stijlgids / website / gebruiker]

## Kleuren
| Rol | Kleurcode | Bron |
|---|---|---|
| Achtergrond | | |
| Tekst | | |
| Accent | | |
| Zacht (tweede titelregel, lijnen) | | |

## Lettertypes
| Gebruik | Naam | Bestand in huisstijl/ |
|---|---|---|
| Titels | | ja / nee |
| Tekst | | ja / nee |

## Logo
- Bestand op lichte achtergrond:
- Bestand op donkere achtergrond:

## Regels
(uit de stijlgids, of wat de gebruiker zegt: wat moet, wat mag niet)

## Wat hij goed of slecht vond
| Datum | Visual | Goed / niet goed | Waarom |
|---|---|---|---|
```

### posts.md

```
# Posts
| Datum | Onderwerp | Soort | Link of tekst | Resultaat na 1 week | Les |
|---|---|---|---|---|---|
```

### planning.md

```
# Planning
| Week | Onderwerp | Soort (perspective, proof, promo) | Kernboodschap | Materiaal | Status (gepland, gepost) |
|---|---|---|---|---|---|

## Vaste momenten
- Reageren bij anderen: [dag en uur, bv. maandag 9u]
```

### leadmagnets.md

```
# Gratis waarde en lead magnets
| Datum | Naam | Groep en vorm | Status (idee, gekozen, uitgewerkt, gebouwd, live) | Link | Resultaten (inschrijvingen, gesprekken) |
|---|---|---|---|---|---|

## Concepten
(per lead magnet: wat in elke stap gekozen werd, en later de prompts en gebouwde stukken)

## Open punten
(per lead magnet: wat nog te bepalen is, bv. datum, gastspreker, toestemming van een klant)

## Berichten
(per lead magnet: de gekozen berichten en opvolgberichten, en de cijfers: verstuurd, antwoorden, ja op de gratis waarde, gesprekken)
```

Het sjabloon voor `profiel.md` staat in `kennismaking.md` ("Het bedrijfsprofiel").
