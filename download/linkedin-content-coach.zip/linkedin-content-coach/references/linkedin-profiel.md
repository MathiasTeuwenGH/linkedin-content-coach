# Het LinkedIn-profiel optimaliseren

Elke goede post stuurt mensen naar het profiel. Daar beslissen ze in een paar seconden of ze volgen, connecteren of een bericht sturen. Het profiel moet dus in één oogopslag zeggen wat de gebruiker doet, voor wie, en waarom ze hem kunnen vertrouwen.

## Werkwijze

1. **Openingsvraag:**
   > Ik kijk je profiel graag na. Doe dit:
   > 1. Ga naar je LinkedIn-profiel, klik op "Meer" en dan op "Opslaan als pdf". Upload die PDF hier.
   > 2. Maak een schermafbeelding van de bovenkant van je profiel (banner, foto en kopregel).
   > 3. Maak een schermafbeelding van je Featured-sectie, als je die hebt.

   In de pdf staan de banner, de profielfoto en Featured niet, daarom de schermafbeeldingen. Plakt hij liever de teksten, ook goed. Ontbreekt iets, zeg dan welk deel je niet kon nakijken.
2. Leg het naast het brein (de ideale klant, het aanbod, de bewijzen, de letterlijke taal van klanten).
3. Loop de onderdelen hieronder af. Geef per onderdeel: wat nu goed is, wat beter kan en waarom, en een concreet voorstel (tekst die hij kan overnemen, in zijn stem).
4. Begin met wat het meeste oplevert: kopregel, banner en About-sectie.

## Profielfoto

- Een echte, recente foto. Kijk in de camera, glimlach, geen zwart-wit.
- Zoom in op het gezicht, zodat je herkenbaar bent op een klein schermpje.
- Genoeg contrast in het gezicht (let op schaduw en licht).
- Een effen achtergrond in een kleur van de huisstijl helpt om herkenbaar te zijn. Dat kan met een eenvoudige tool die de achtergrond weghaalt.

## Banner

De banner is de grootste plaats op het profiel en blijft vaak leeg of vaag. Een goede banner:
- noemt de **ideale klant**, het **doel van die klant** en de **oplossing** (bv. "Ik help [ideale klant] [doel bereiken] met [oplossing]")
- geeft de **categorie** die in één woord zegt wat de gebruiker is (de ene categorie uit het brein)
- toont **bewijs**: twee à vier tastbare resultaten van klanten
- laat ruimte onder de profielfoto (die bedekt een deel van de banner)
- past bij de huisstijl, en bij de wereld van de ideale klant

Een andere mogelijkheid: een licht prikkelende tekst die de ideale klant doet nadenken. Prikkelend mag, vaag niet.

Vermijd: alleen een logo, een stockfoto, kleuren die het lezen moeilijk maken, en een prikkelende maar vage vraag.

**Zo maak je de banner** (dezelfde werkwijze als de visuals, zie `visuals.md`):
1. **Eerst de tekst.** Stel de tekst voor: één zin met ideale klant, doel en oplossing, de categorie, en 2 à 4 resultaten uit de bewijsbank. De gebruiker keurt goed of past aan.
2. **Dan het beeld:** 1584 x 396 pixels (het formaat van een LinkedIn-banner), in de huisstijl met het echte logo. Geen tekst linksonder: daar komt de profielfoto. De belangrijkste tekst in het midden en rechts, zodat ze ook op de gsm leesbaar blijft (daar snijdt LinkedIn de banner anders bij). Lever een PNG. Kan je in dit gesprek geen beeld maken, lever dan de tekst met opmaakinstructies voor Canva.
3. **De visuele controle** (zie `visuele-controle.md`): leesbaar op de gsm, genoeg contrast, niets achter de profielfoto, het juiste formaat.
4. **Opladen:** op je profiel klik je op het potloodje in de banner.

Formules om te vertrekken (altijd invullen met eigen details):
- "Wat als [dienst of product] je [verlangen] gaf? Hoeveel meer [voordeel] zou je dan halen?"
- "Stop met [negatief gevolg]. Begin met [ideale uitkomst]."

## Kopregel (headline)

Wat onder de naam staat, verschijnt overal: bij elke post, reactie en connectieverzoek. Zeg wat je doet voor wie, niet alleen je functietitel.

Kort, duidelijk en sterk. Mensen vinden je ook via de zoekfunctie, dus gebruik de woorden waarop je ideale klant zoekt.

Formules:
- "Ik help [ideale klanten] [verlangen] met [dienst of product], zonder [pijn]."
- "[Dienst of product] voor [ideale klant] die [verlangen] wil in [periode]."
- "Ik help [ideale klant] met [oplossing] zodat ze [resultaat] halen."
- "[Ideale klant] worstelt met [probleem]? Ik help ze naar [resultaat]."
- "[Ideale klant] worstelt met [probleem]. Ik bied [oplossing]. Het resultaat: [cijfer]."

Kijk ook hoe grotere accounts in de branche het doen, en maak het daarna eigen.

## About-sectie

Schrijf de About-sectie als een verhaal in de ik-vorm (nooit in de derde persoon), met de opbouw van een promopost:
1. **Pijn:** een licht dramatische hook die de ideale klant herkent, met pijn die hij kent.
2. **Gevolg:** wat er misloopt als je niets doet of het verkeerd aanpakt.
3. **Ideale situatie:** waar de ideale klant naartoe wil.
4. **Oplossing:** bewijs van geloofwaardigheid, wat je aanbiedt (eventueel genummerd, zonder prijs), en een oproep ("Stuur me een bericht als ...").

Vergeet het "ik" in het begin: het gaat over de ideale klant. Begin bij pijn die hij kent en wat hij al probeerde zonder resultaat, maak duidelijk dat het over hem gaat, beschrijf de droomsituatie met concrete uitkomsten, en toon dat jij die kunt leveren. Eventueel een extra: iets gratis of een garantie. Eindig met een vraag ("Wil je [resultaat]?") en een oproep (een bericht of een mail naar ...).

Vertrek liefst van het eigen verhaal uit deel 4 van de contentgids. Een sterke About-sectie kan later ook als post gebruikt worden.

## Featured

- Bv. een link om rechtstreeks een gratis kennismakingsgesprek in te plannen, en de website.
- Geen posts, maar links naar de belangrijkste oproepen: een gesprek inplannen (gratis of betaald), een nieuwsbrief of gratis gids, een betaald product.
- Maximaal drie, om het eenvoudig te houden.

## Link in het profiel

Eén link die naar de belangrijkste oproepen leidt (een agendalink om een gesprek in te plannen, een eenvoudige linkpagina, later de website). Test af en toe welke titel het best werkt. Kun je onderwerpen of hashtags aan je profiel toevoegen, kies dan de onderwerpen waarover je post: zo vinden mensen je ook daarlangs.

## Ervaring

- Oude functies mag je kort houden. Werk de huidige functie volledig uit.
- Vertel wat je doet, beschrijf je ideale klant, voeg posts met klantcases toe, en zet er vaardigheden en een link bij.

## Vaardigheden en opleiding

Lage prioriteit. Steek de tijd liever in echt bewijs.

## Aanbevelingen

Vraag (oude) klanten om een aanbeveling. Stuur de aanvraag via LinkedIn zelf, dat maakt het makkelijk. Vraag om in hun aanbeveling drie dingen te zeggen:
1. Het probleem: waarom kozen ze voor jou?
2. De oplossing: hoe verliep het samenwerken?
3. Het resultaat: wat leverde het concreet op?

## Activiteit

Het profiel toont de laatste posts. Een mix van verhalen en ervaringen, expertise tonen en promo, minstens 2 keer per week (3 is ideaal, meer is goed zolang je niet opgebrand raakt), maakt het profiel geloofwaardig. Zie `contentmix.md`.
